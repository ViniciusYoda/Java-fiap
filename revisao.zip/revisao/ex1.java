public class ex1 {

   public static void main(String[] args) {
      int numero = -10;
      System.out.println(numero > 0 ? "Numero é positivo" : "Numero é negativo");
   System.out.println(numero % 2 == 0 ? "Numero é par" : "Numero é impar");
   }
}