package cp2;

public class Teste {
	public static void main(String[] args) {
	  ContaCorrente cc = new ContaCorrente();
	  
	}
}
